/*
Name:OMAR TAREK IBRAHIM SALAH
PHONE:01140058268
DIPLOMA60
 */


#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
unsigned char seconds =0;
unsigned char minuites =0;
unsigned char hours =0;

void Timer_Sec_Init(void){
	TCNT1 =0;
	OCR1A = 1000;
	TIMSK = (1<<OCIE1A);
	TCCR1A = (1<<FOC1A);
	TCCR1B=(1<<WGM12)|(1<<CS12)|(1<<CS10);
}

void Interrupt0_EN(void){
	MCUCR |= (1<<ISC01);
	GICR |= (1<<INT0);
	DDRD &= ~(1<<PD2);
	PORTD |= (1<<PD2);
}

ISR (INT0_vect){
	seconds=0;
	hours =0;
	minuites =0;
}

void Interrupt1_EN(void){
	MCUCR |= (1<<ISC11)|(1<<ISC10);
	GICR |= (1<<INT1);
	DDRD &= ~(1<<PD3);
}

ISR (INT1_vect){
	TIMSK &= ~(1<<OCIE1A);
}

void Interrupt2_EN(void){
	MCUCSR &= ~(1<<ISC2);
	GICR |= (1<<INT2);
	DDRB &= ~(1<<PB2);
	PORTB |= (1<<PB2);
}

ISR (INT2_vect){
	TIMSK |= (1<<OCIE1A);
}

ISR(TIMER1_COMPA_vect){
	seconds++;
	PORTD++;
	if(seconds==60){
		seconds =0;
		minuites++;
	}
	if(minuites==60){
			minuites =0;
			hours++;
		}
	if(hours==99){
				minuites =0;
				seconds =0;
				hours =0;
			}


}


int main(void){
	SREG = (1<<7);
	DDRC =0xff;
	DDRA = 0x3f;
	PORTA=0;
	PORTC = 0;
	Timer_Sec_Init();
	Interrupt0_EN();
	Interrupt1_EN();
	Interrupt2_EN();
	unsigned char counter =0;
	while(1){
		PORTA=(1<<counter);
		PORTC = (PORTC&0xf0)|((seconds%10)&(0x0f));
		counter++;
		_delay_ms(2);
		PORTA=(1<<counter);
		PORTC = (PORTC&0xf0)|(((seconds/10)%10)&(0x0f));
		counter++;
		_delay_ms(2);
		PORTA=(1<<counter);
		PORTC = (PORTC&0xf0)|((minuites%10)&(0x0f));
		counter++;
		_delay_ms(2);
		PORTA=(1<<counter);
		PORTC = (PORTC&0xf0)|(((minuites/10)%10)&(0x0f));
		counter++;
		_delay_ms(2);
		PORTA=(1<<counter);
		PORTC = (PORTC&0xf0)|((hours%10)&(0x0f));
		counter++;
		_delay_ms(2);
		PORTA=(1<<counter);
		PORTC = (PORTC&0xf0)|(((hours/10)%10)&(0x0f));
		counter=0;
		_delay_ms(2);
	}


	return 0;
}
